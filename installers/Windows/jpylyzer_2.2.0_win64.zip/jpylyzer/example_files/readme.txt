Test images for jpylyzer. 
Created by Johan van der Knijff, 1 March 2012.

Image source: 

http://commons.wikimedia.org/wiki/File:1783_balloonj.jpg

"1786 description of the historic Montgolfier Brothers' 1783 balloon flight. Illustration with engineering proportions and description."

Public Domain.

Description of images:

1. balloon.jp2: lossily compressed JP2. Contains XML box, UUID Info box 
   (latter with bogus content) and codestream comment.  
2. balloon_trunc1.jp2: last byte missing
3. balloon_trunc2.jp2: truncated at byte 5000
4. balloon_trunc3jp2: missing data in most of last tile-part
 