#! /usr/bin/env python3
"""jpylyzer.__main__: executed when jpylyzer directory is called as script."""

from .jpylyzer import main
main()
